<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="src/style.css"/>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
        <title>Inname</title>
        <meta charset="UTF-8" />
    </head>
    <body>
  
            <section class="home-hero">
           <div class="home-hero-area">
            <div class="home-hero-text">
            <img class="home-logo" src="src/images/recycle.png"  alt="Mijn logo"/>
                <h2> ReMaS Recycling</h2>
                <p>Textvak<p>
               
            <div class="nav">

            <nav> 
                <ul>
                    <a href="Inname.php">Inname</a>
                    <a href="Verwerking.php">Verwerking</a>
                    <a href="Uitgifte.php">Uitgifte</a>
                    <a href="Rapportage.php">Rapportage</a>
                    <a href="Onderhoud.php">Onderhoud</a>
                </ul>
            </nav>
            </div>
            </div>
        </section>
    

        <script src="src/app.js"></script>
    </body>
</html>